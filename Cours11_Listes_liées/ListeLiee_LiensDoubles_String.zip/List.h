/****************************************************************************
 * Fichier: List.h
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Definition de la classe List
 ****************************************************************************/


#ifndef _LIST_H_
#define _LIST_H_

#include <string>
#include "Iterator.h"

class List
{
	public:
		List();

		void push_back(string s); // pour ins�rer � la fin
		void insert(Iterator pos, string s);
		Iterator erase(Iterator pos);

		Iterator begin(); // retourne un it�r. qui pointe sur le premier item
		Iterator end(); // retourne un it�r. qui pointe apres le dernier item

	private:
		Node* first_;
		Node* last_;
};

#endif

