/****************************************************************************
 * Fichier: Iterator.cpp
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Implementation de la classe Iterator
 ****************************************************************************/

#include "Iterator.h"


Iterator::Iterator()
{
	position_ = 0;
	last_ = 0;
}

void Iterator::next()
{
	// Si on est apres le dernier element
	assert( position_ != 0 );

	position_ = position_->next_;
}


void Iterator::previous()
{
	if (position_ == 0)
		position_ = last_;
	else
		position_ = position_->previous_;

	// Si on est avant le premier element
	assert( position_ != 0 );
}


string Iterator::get() const
{
	// Si on est apres le dernier element
	assert( position_ != 0 );

	return position_->data_;
}


bool Iterator::equals(Iterator b) const
{
	return position_ == b.position_;
}

