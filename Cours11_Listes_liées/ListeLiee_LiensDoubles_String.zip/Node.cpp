/****************************************************************************
 * Fichier: Node.cpp
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Impl�mentation de la classe Node
 ****************************************************************************/

#include "Node.h"

Node::Node(string s)
{
	data_=s;
	previous_=0;
	next_=0;
}