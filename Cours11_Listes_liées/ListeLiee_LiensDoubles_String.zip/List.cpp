/****************************************************************************
 * Fichier: List.cpp
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Implementation de la classe List
 ****************************************************************************/

#include "List.h"
#include <cassert>

List::List()
{
	first_=0;
	last_=0;
}


/****************************************************************************
 * Fonction:	List::begin
 * Description: retourne un iterateur qui pointe sur le premier element
 * Param�tres:	aucun
 * Retour:		(Iterator) un iterateur representant le premier element
 ****************************************************************************/
Iterator List::begin()
{
	Iterator iter;
	iter.position_ = first_;
	iter.last_ = last_;

	return iter;
}


/****************************************************************************
 * Fonction:	List::ned
 * Description: retourne un iterateur qui pointe sur le dermier element
 * Param�tres:	aucun
 * Retour:		(Iterator) un iterateur representant le dermier element
 ****************************************************************************/
Iterator List::end()
{
	Iterator iter;
	iter.position_ = 0;
	iter.last_ = last_;

	return iter;
}

/****************************************************************************
 * Fonction:	List::push_back
 * Description: ajoute un element a la fin de la liste
 * Param�tres:	- (string) l'element a ajouter
 * Retour:		aucun
 ****************************************************************************/
void List::push_back(string s)
{
	Node* newnode = new Node(s);

	if (last_ == 0) /* la liste est vide */
	{
		first_ = newnode;
		last_ = newnode;
	}
	else
	{
		newnode->previous_ = last_;
		last_->next_ = newnode;
		last_ = newnode;
	}
}


/****************************************************************************
 * Fonction:	List::insert
 * Description: insere un element avant celui pointer par l'iterateur
 * Param�tres:	- (Iterator) ou inserer
 *				- (string) element a inserer
 * Retour:		aucun
 ****************************************************************************/
void List::insert(Iterator iter, string s)
{
	// Si on veut l'inserer a la fin (apres le dernier element)
	if (iter.position_ == 0)
	{
		push_back(s);
		return;
	}

	Node* after = iter.position_;
	Node* before = after->previous_;
	Node* newnode = new Node(s);

	newnode->previous_ = before;
	newnode->next_ = after;
	after->previous_ = newnode;

	// Si on veut inserer avant le premier element
	if (before == 0)
		first_ = newnode;

	else
		before->next_ = newnode;
}


/****************************************************************************
 * Fonction:	List::erase
 * Description: elimine un element de la liste et recolle les morceaux
 * Param�tres:	- (Iterator) lequel enlever
 * Retour:		(Iterator) qui pointe sur l'element suivant celui enleve
 ****************************************************************************/
Iterator List::erase(Iterator i)
{
	Iterator iter = i;
	assert(iter.position_ != 0);

	Node* remove = iter.position_;
	Node* before = remove->previous_;
	Node* after = remove->next_;

	// Enlever le premier element?
	if (remove == first_)
		first_ = after;
	else
		before->next_ = after;

	// Enlever le dernier element?
	if (remove == last_)
		last_ = before;
	else
		after->previous_ = before;

	iter.position_ = after;
	delete remove;

	return iter;
}