/****************************************************************************
 * Fichier: Node.h
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Definition de la classe Node
 ****************************************************************************/

#ifndef _NODE_H_
#define _NODE_H_

#include <string>
using namespace std;

class Node
{
	// Ces classes auront acces a tous les attributs et methodes de la classe Node
	friend class List;
	friend class Iterator;

	public:
		Node(string s);

	private:
		string data_;
		Node* previous_;
		Node* next_;
};

#endif