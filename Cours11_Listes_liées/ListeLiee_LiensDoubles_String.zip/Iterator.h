/****************************************************************************
 * Fichier: Iterator.h
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Definition de la classe Iterator
 ****************************************************************************/

#ifndef _ITERATOR_H_
#define _ITERATOR_H_


#include "Node.h"

#include <string>
#include <cassert>
using namespace std;

class Iterator 
{
	// List peut acceder tout les attributs de Iterator
	friend class List;

	public:
		Iterator();
		string get() const;
		void next();
		void previous();
		bool equals(Iterator b) const;

	private:
		Node* position_;
		Node* last_;
};

#endif
