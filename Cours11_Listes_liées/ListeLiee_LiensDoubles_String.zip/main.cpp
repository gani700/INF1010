/****************************************************************************
 * Fichier: main.cpp
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Manipulations de notre systeme de liste a liens doubles
 ****************************************************************************/


#include "List.h"
#include "Node.h"
#include "Iterator.h"

#include <iostream>
using namespace std;


int main()
{
	// Creation et remplissage de notre liste

	List personnel;
	personnel.push_back( "Michel" );
	personnel.push_back( "Robert" );
	personnel.push_back( "Claudia" );
	personnel.push_back( "Mohamed" );


	// Afficher tous les elements de la liste

	Iterator pos = personnel.begin();
	Iterator fin = personnel.end();
	
	while( !pos.equals(fin) )
	{
		cout << pos.get() << endl; 
		pos.next();
	}
	cout << endl;


	// Chercher Claudia pour la supprimer

	pos = personnel.begin();
	fin = personnel.end();
	
	while( !pos.equals(fin) && pos.get() != "Claudia" )
		pos.next();

	if( !pos.equals(fin) )
	{
		personnel.erase( pos );
	}

	
	// Reafficher la liste apres la suppression de Claudia

	cout << "apres suppression" << endl;
	pos = personnel.begin();
	fin = personnel.end();

	while( !pos.equals(fin) )
	{
		cout << pos.get() << endl; 
		pos.next();
	}
	cout << endl;

	return 0;
}

