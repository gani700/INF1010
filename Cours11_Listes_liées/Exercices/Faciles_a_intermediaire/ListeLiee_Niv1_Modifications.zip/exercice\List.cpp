#include "List.h"
#include <cassert>

List::List()
{
	first_=0;
	last_=0;
}

Iterator List::begin()
{
	Iterator iter;
	iter.position_ = first_;
	iter.last_ = last_;
	return iter;
}
Iterator List::end()
{
	Iterator iter;
	iter.position_ = 0;
	iter.last_ = last_;
	return iter;
}

void List::push_back(string s)
{
	Node* newnode = new Node(s);
	if (last_ == 0) /* la liste est vide */
	{
		first_ = newnode;
		last_ = newnode;
	}
	else
	{
		newnode->previous_ = last_;
		last_->next_ = newnode;
		last_ = newnode;
	}
}

void List::insert(Iterator iter, string s)
{
	if (iter.position_ == 0)
	{
		push_back(s);
		return;
	}
	Node* after = iter.position_;
	Node* before = after->previous_;
	Node* newnode = new Node(s);
	newnode->previous_ = before;
	newnode->next_ = after;
	after->previous_ = newnode;
	if (before == 0)
		first_ = newnode;
	else
		before->next_ = newnode;
}

Iterator List::erase(Iterator i)
{
	Iterator iter = i;
	assert(iter.position_ != 0);
	Node* remove = iter.position_;
	Node* before = remove->previous_;
	Node* after = remove->next_;
	if (remove == first_)
		first_ = after;
	else
		before->next_ = after;
	if (remove == last_)
		last_ = before;
	else
		after->previous_ = before;
	iter.position_ = after;
	delete remove;
	return iter;
}