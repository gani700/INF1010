#include "List.h"
#include "Node.h"
#include "Iterator.h"
#include <iostream>

using namespace std;

int main()
{
	List personnel;
	personnel.push_back("Michel");
	personnel.push_back("Robert");
	personnel.push_back("Claudia");
	personnel.push_front("Mohamed");

	Iterator pos=personnel.begin();
	Iterator fin=personnel.end();

	while(!pos.equals(fin))
	{
		cout << pos.get() << endl; 
		pos.next();
	}
	
	pos=personnel.begin();
	fin=personnel.end();


	while(!pos.equals(fin) && pos.get() != "Claudia")
		pos.next();

	if(!pos.equals(fin))
	{
		personnel.erase(pos);
	}

	cout << "apres suppression" << endl;
	
	List personnel2;
	personnel2=personnel;

	pos=personnel.begin();
	fin=personnel.end();

	while(!pos.equals(fin))
	{
		cout << pos.get() << endl; 
		pos.next();
	}

	pos=personnel2.begin();
	fin=personnel2.end();

	while(!pos.equals(fin))
	{
		cout << pos.get() << endl; 
		pos.next();
	}

	cout << "Taille: " <<personnel.taille() << endl;

	personnel.vider();

	return 0;
}

