#include "List.h"
#include <cassert>

List::List()
{
	first_=0;
	last_=0;
	nombreNodes_=0;
}

Iterator List::begin()
{
	Iterator iter;
	iter.position_ = first_;
	iter.last_ = last_;
	return iter;
}
Iterator List::end()
{
	Iterator iter;
	iter.position_ = 0;
	iter.last_ = last_;
	return iter;
}

void List::push_back(string s)
{
	Node* newnode = new Node(s);
	if (last_ == 0) /* la liste est vide */
	{
		first_ = newnode;
		last_ = newnode;
	}
	else
	{
		newnode->previous_ = last_;
		last_->next_ = newnode;
		last_ = newnode;
	}
	nombreNodes_++;
}

void List::insert(Iterator iter, string s)
{
	nombreNodes_++;
	if (iter.position_ == 0)
	{
		push_back(s);
		return;
	}
	Node* after = iter.position_;
	Node* before = after->previous_;
	Node* newnode = new Node(s);
	newnode->previous_ = before;
	newnode->next_ = after;
	after->previous_ = newnode;
	if (before == 0)
		first_ = newnode;
	else
		before->next_ = newnode;
}

Iterator List::erase(Iterator i)
{
	nombreNodes_--;
	Iterator iter = i;
	assert(iter.position_ != 0);
	Node* remove = iter.position_;
	Node* before = remove->previous_;
	Node* after = remove->next_;
	if (remove == first_)
		first_ = after;
	else
		before->next_ = after;
	if (remove == last_)
		last_ = before;
	else
		after->previous_ = before;
	iter.position_ = after;
	delete remove;
	return iter;
}

int List::taille()
{
	return nombreNodes_;
}

void List::vider()
{
	if( first_!=0) 
	{
		Iterator courant= begin();
		Iterator fin= end();
		Iterator temp;
		while(!courant.equals(fin))
		{
			temp=courant;
			courant.next();
			delete temp.position_;
		}
	}
	first_=0;
	last_=0;
	nombreNodes_=0;
}

void List::push_front(string s)
{
	Node* newnode = new Node(s);
	if (last_ == 0) /* la liste est vide */
	{
		first_ = newnode;
		last_ = newnode;
	}
	else
	{
		newnode->next_ = first_;
		first_->previous_ = newnode;
		first_ = newnode;
	}
	nombreNodes_++;
}

List::~List()
{
	vider();
}

List& List::operator = (List &liste)
{
	if(&liste != this)
	{
		vider();
		Iterator courant=liste.begin();
		Iterator fin=liste.end();
		while(!courant.equals(fin))
		{
			push_back(courant.get());
			courant.next();
		}
	}
	return *this;
}

List::List(List &liste)
{

		Iterator courant=liste.begin();
		Iterator fin=liste.end();
		while(!courant.equals(fin))
		{
			push_back(courant.get());
			courant.next();
		}

}