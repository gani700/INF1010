#ifndef _NODE_H_
#define _NODE_H_

#include <string>
using namespace std;

class Node
{
public:
	Node(string s);
private:
	string data_;
	Node* previous_;
	Node* next_;
	friend class List;
	friend class Iterator;
};

#endif