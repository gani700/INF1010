#ifndef _LIST_H_
#define _LIST_H_

#include <string>
#include "Iterator.h"

class List
{
public:
	List();
	void push_back(string s); // pour ins�rer � la fin
	void insert(Iterator pos, string s);
	Iterator erase(Iterator pos);
	Iterator begin(); // retourne un it�r. qui pointe
	// sur le premier item
	Iterator end(); // retourne un it�r. qui pointe
	// apres le dernier item

	int taille(); // Question 1

	void vider(); // Question 1

	void push_front(string s); // Question 1

	~List(); // Question 1

	List& operator = (List &liste); // Question 1

	List(List &liste);

private:
	Node* first_;
	Node* last_;
	int nombreNodes_; //Question 1
};

#endif

