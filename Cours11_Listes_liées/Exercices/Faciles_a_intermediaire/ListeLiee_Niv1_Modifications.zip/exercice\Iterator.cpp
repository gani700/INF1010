#include "Iterator.h"
#include <cassert>

Iterator::Iterator()
{
	position_=0;
	last_=0;
}

void Iterator::next()
{
	assert(position_ != 0);
	position_ = position_->next_;
}
void Iterator::previous()
{
	if (position_ == 0)
		position_ = last_;
	else
		position_ = position_->previous_;
	assert(position_ != 0);
}

string Iterator::get() const
{
	assert(position_ != 0);
	return position_->data_;
}

bool Iterator::equals(Iterator b) const
{
	return position_ == b.position_;
}

