#ifndef _NODE_H_
#define _NODE_H_

template <typename T>
class List;

template <typename T>
class Iterator;

template <typename T>
class Node
{
public:
	Node(T s);

private:
	T data_;
	Node<T>* previous_;
	Node<T>* next_;
	friend class List<T>;
	friend class Iterator<T>;
};

template <typename T>
Node<T>::Node(T s)
{
	data_ = s;
	previous_ = 0;
	next_ = 0;
}

#endif