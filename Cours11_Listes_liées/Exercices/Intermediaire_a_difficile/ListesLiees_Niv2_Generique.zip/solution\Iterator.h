#ifndef _ITERATOR_H_
#define _ITERATOR_H_

#include "Node.h"

#include <cassert>
using namespace std;

template <typename T>
class Iterator 
{
public:
	Iterator();
	T get() const;
	void next();
	void previous();
	bool equals(Iterator<T> b) const;
private:
	Node<T>* position_;
	Node<T>* last_;
	friend class List<T>;
};

template <typename T>
Iterator<T>::Iterator()
{
	position_ = 0;
	last_ = 0;
}

template <typename T>
void Iterator<T>::next()
{
	assert(position_ != 0);
	position_ = position_->next_;
}

template <typename T>
void Iterator<T>::previous()
{
	if (position_ == 0)
		position_ = last_;
	else
		position_ = position_->previous_;
	assert(position_ != 0);
}

template <typename T>
T Iterator<T>::get() const
{
	assert(position_ != 0);
	return position_->data_;
}

template <typename T>
bool Iterator<T>::equals(Iterator b) const
{
	return position_ == b.position_;
}

#endif
