#ifndef _ITERATOR_H_
#define _ITERATOR_H_

#include <string>
#include "Node.h"

class Iterator 
{
public:
	Iterator();
	string get() const;
	void next();
	void previous();
	bool equals(Iterator b) const;
private:
	Node* position_;
	Node* last_;
	friend class List;
};

#endif
