#ifndef _LIST_H_
#define _LIST_H_

#include "Iterator.h"

#include <cassert>
using namespace std;

template <typename T>
class List
{
public:
	List();

	void push_back(T s);
	void insert(Iterator<T> pos, T s);
	Iterator<T> erase(Iterator<T> pos);

	Iterator<T> begin();
	Iterator<T> end();

private:
	Node<T>* first_;
	Node<T>* last_;
};


template <typename T>
List<T>::List()
{
	first_=0;
	last_=0;
}

template <typename T>
Iterator<T> List<T>::begin()
{
	Iterator<T> iter;
	iter.position_ = first_;
	iter.last_ = last_;
	return iter;
}

template <typename T>
Iterator<T> List<T>::end()
{
	Iterator<T> iter;
	iter.position_ = 0;
	iter.last_ = last_;
	return iter;
}

template <typename T>
void List<T>::push_back(T s)
{
	Node<T>* newnode = new Node<T>(s);
	if (last_ == 0) /* la liste est vide */
	{
		first_ = newnode;
		last_ = newnode;
	}
	else
	{
		newnode->previous_ = last_;
		last_->next_ = newnode;
		last_ = newnode;
	}
}


template <typename T>
void List<T>::insert(Iterator<T> iter, T s)
{
	if (iter.position_ == 0)
	{
		push_back(s);
		return;
	}
	Node<T>* after = iter.position_;
	Node<T>* before = after->previous_;
	Node<T>* newnode = new Node<T>(s);
	newnode->previous_ = before;
	newnode->next_ = after;
	after->previous_ = newnode;
	if (before == 0)
		first_ = newnode;
	else
		before->next_ = newnode;
}

template <typename T>
Iterator<T> List<T>::erase(Iterator<T> i)
{
	Iterator<T> iter = i;
	assert(iter.position_ != 0);
	Node<T>* remove = iter.position_;
	Node<T>* before = remove->previous_;
	Node<T>* after = remove->next_;
	if (remove == first_)
		first_ = after;
	else
		before->next_ = after;
	if (remove == last_)
		last_ = before;
	else
		after->previous_ = before;
	iter.position_ = after;
	delete remove;
	return iter;
}

#endif

