#include "List.h"
#include "Node.h"
#include "Iterator.h"

#include <iostream>
#include <string>
using namespace std;

int main()
{
	List<string> raccompagnateurs;

	raccompagnateurs.push_back("Sophie Lange");
	raccompagnateurs.push_back("Bret Legomery");
	raccompagnateurs.push_back("Tilda MacMurphy");

	Iterator<string> iter = raccompagnateurs.begin();
	iter.next();
	iter.next();

	raccompagnateurs.insert(iter, "Arnljotur Thorir");

	iter = raccompagnateurs.begin();

	cout << "Les raccompagnateurs de la soiree : " << endl;
	for(iter; !iter.equals(raccompagnateurs.end()); iter.next())
		cout << "   " << iter.get() << endl;
}

