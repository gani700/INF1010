#ifndef _LIST_H_
#define _LIST_H_

#include <string>
#include "Iterator.h"

class List
{
public:
	List();

	void push_back(string s); // pour ins�rer � la fin
	void insert(Iterator pos, string s);

	Iterator erase(Iterator pos);
	Iterator begin(); // retourne un it�r. qui pointe
	// sur le premier item
	Iterator end(); // retourne un it�r. qui pointe
	// apres le dernier item

	/* Question 2:
	Le dernier noeud doit pointer sur le premier. 
	*/

private:
	Node* first_;
	Node* last_;
};

#endif

