#include "Node.h"

Node::Node(string s)
{
	data_=s;
	previous_=0;
	next_=0;
}