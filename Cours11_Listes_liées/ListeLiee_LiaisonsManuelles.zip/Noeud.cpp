/****************************************************************************
 * Fichier: Noeud.cpp
 * Auteur: Guillaume-Alexandre Bilodeau
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Implementation de la classe Noeud
 ****************************************************************************/

#include "Noeud.h"

Noeud::Noeud(int valeur)
{
	valeur_	= valeur;
	suivant_	= 0;
	precedent_	= 0;
}

Noeud* Noeud::obtenirSuivant()
{
	return suivant_;
}

void Noeud::modifierSuivant(Noeud* suivant)
{
	suivant_=suivant;
}

Noeud* Noeud::obtenirPrecedent()
{
	return precedent_;
}

void Noeud::modifierPrecedent(Noeud* precedent)
{
	precedent_=precedent;
}

int Noeud::obtenirValeur()
{
	return valeur_;
}
