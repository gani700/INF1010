/****************************************************************************
 * Fichier: Noeud.h
 * Auteur: Guillaume-Alexandre Bilodeau
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Definition de la classe Noeud
 ****************************************************************************/

#ifndef _NOEUD_H_
#define _NOEUD_H_

class Noeud
{
	public:
		Noeud(int valeur=0);

		Noeud*	obtenirSuivant();
		void	modifierSuivant(Noeud* suivant);

		Noeud*	obtenirPrecedent();
		void	modifierPrecedent(Noeud* precedent);

		int		obtenirValeur();
		
	private:
		int		valeur_;
		Noeud	*suivant_;
		Noeud	*precedent_;
};

#endif