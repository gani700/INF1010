/****************************************************************************
 * Fichier: main.cpp
 * Auteur: Guillaume-Alexandre Bilodeau
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Manipulations directes des liens d'une liste liee
 ****************************************************************************/

#include "Noeud.h"

int main()
{
	// Pour bien voir la liste, mettre un break point a la ligne return 0.
	// Puis au debogage, regarder l'enchainement a partir du pointeur tete.

	Noeud *tete, *queue, *nouveau, *courant;
	queue=0;
	tete=0;

	//insertion tete
	nouveau = new Noeud( 1 );
	nouveau->modifierSuivant( tete );
	nouveau->modifierPrecedent( 0 );
	tete  = nouveau;
	queue = nouveau;

	//insertion tete
	nouveau = new Noeud( 2 );
	nouveau->modifierSuivant( tete );
	nouveau->modifierPrecedent( 0 );
	tete->modifierPrecedent( nouveau );
	tete = nouveau;

	//insertion fin
	nouveau = new Noeud( 4 );
	nouveau->modifierSuivant( 0 );
	nouveau->modifierPrecedent( queue );
	queue->modifierSuivant( nouveau );
	queue = nouveau;

	//insertion milieu
	nouveau = new Noeud( 3 );

	courant = tete;
	while( courant->obtenirValeur() != 4 )
		courant = courant->obtenirSuivant();

	nouveau->modifierSuivant( courant );
	nouveau->modifierPrecedent( courant->obtenirPrecedent() );
	courant->obtenirPrecedent()->modifierSuivant( nouveau );
	courant->modifierPrecedent( nouveau );

	return 0;
}

