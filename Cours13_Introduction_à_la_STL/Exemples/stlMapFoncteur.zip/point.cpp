/****************************************************************************
 * Fichier: Point.h
 * Auteur: Georges Abou-Khalil
 * Date: 2 sept 2008
 * Description: Impl�mentation de la classe Point
 ****************************************************************************/

#include "Point.h"
#include <iostream>

using namespace std;

/****************************************************************************
 * Fonction: Point:Point
 * Description: Constructeur par d�faut
 * Param�tres: aucun
 * Retour: aucun
 ****************************************************************************/
Point::Point()
{
	cout << "Constructeur par defaut" << endl;
	x_ = y_ = 0.0;
}


/****************************************************************************
 * Fonction: Point:Point
 * Description: Constructeur par param�tres
 * Param�tres: - double x: valeur de x_
 *             - double y: valeur de y_
 * Retour: aucun
 ****************************************************************************/
Point::Point(double x, double y)
{
	//cout << "Constructeur par parametre" << endl;
	x_ = x;
	y_ = y;
}

/****************************************************************************
 * Fonction: Point:getX
 * Description: Retourne x_
 * Param�tres: aucun
 * Retour: (double) la valeur de x_
 ****************************************************************************/
double Point::getX() const
{
	return x_;
}

/****************************************************************************
 * Fonction: Point:getY
 * Description: Retourne y_
 * Param�tres: aucun
 * Retour: (double) la valeur de y_
 ****************************************************************************/
double Point::getY() const
{
	return y_;
}

/****************************************************************************
 * Fonction: Point:setX
 * Description: Modifie x_
 * Param�tres: - double x: la nouvelle valeur de x_
 * Retour: aucun
 ****************************************************************************/
void Point::setX(double x)
{
	x_ = x;
}

/****************************************************************************
 * Fonction: Point:setY
 * Description: Retourne y_
 * Param�tres: - double y: la nouvelle valeur de y_
 * Retour: aucun
 ****************************************************************************/
void Point::setY(double y)
{
	y_ = y;
}

ostream & operator<<(ostream& sortie, const Point & p) 
{
	sortie<<"("<<p.getX()<<","<<p.getY()<<")"<<endl;
	return sortie;
}


bool Point::operator<(const Point& p) const
{
	return x_<p.x_;
}