#ifndef FORME_H
#define FORME_H

#include <string>

using namespace std;

class Forme
{
public:
	Forme(string nom):nom_(nom){};

	string obtenirNom() const {return nom_;};

private:
	string nom_;

};



#endif