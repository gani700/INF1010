#ifndef DEPLACEMENT_H
#define DEPLACEMENT_H
#include <utility>
 using namespace std;
class Deplacement
{
public:
	Deplacement(double dx,double dy):dx_(dx), dy_(dy){};

	void modifierDx(double dx){dx_ = dx;};

	void modifierDy(double dy){dy_ = dy;};

	void operator()(pair<Point, Forme> pf)
	{
		pf.first.setX(pf.first.getX() + dx_);
		pf.first.setY(pf.first.getY() + dy_);
	}

private:
	double dx_;
	double dy_;

};


#endif