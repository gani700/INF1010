
/****************************************************************************
 * Fichier: Point.h
 * Auteur: Georges Abou-Khalil
 * Date: 2 sept 2008
 * Description: D�finition de la classe Point
 ****************************************************************************/

#include <iostream>

using namespace std;

#ifndef POINT_H_
#define POINT_H_

class Point
{
public:
	Point();
	Point(double x, double y);

	double getX() const;
	double getY() const;

	void setX(double x);
	void setY(double y);

	bool operator < (const Point& p)const;

private:
	double x_;
	double y_;
};

ostream & operator<<(ostream& sortie, const Point & p);

#endif // POINT_H_
