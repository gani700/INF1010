#include "point.h"
#include "Forme.h"
#include "Deplacement.h"

#include <utility>
#include <map>
#include <iostream>
#include <vector>

using namespace std;

int main() 
{
	map<Point, Forme> points;
	map<Point, Forme>::iterator pos;

	Deplacement deplace(5,2);

		for(int i=0; i<10; i++) 
	{
		Point p(i+10, i*2);
		Forme f("carre" + char(i+49));

		//points.insert(make_pair(p, f)) ou ;
		points.insert(pair<Point,Forme>(p, f));
	}
		pos = points.begin();

		while(pos!=points.end())
		{
			deplace(*pos);
			cout<<pos->first;
			pos++;
		}

	return 0;


}