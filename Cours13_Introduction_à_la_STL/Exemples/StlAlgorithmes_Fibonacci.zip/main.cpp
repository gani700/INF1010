/****************************************************************************
 * Fichier: main.cpp
 * Auteur: G.A. Bilodeau
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Utilisation d'algorithmes STL avec nos propres fonctions et 
 *				des foncteurs de la STL
 ****************************************************************************/

#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>
#include <functional>
using namespace std;


// Retourne � chaque appel un terme de la s�rie de Fibonacci
int fibonacci() // fonction g�n�ratrice, aucun param�tre
{
	static int n1 = 0; // n'est initialise qu'au premier appel de la fonction
	static int n2 = 1; // meme chose
	int temp = n1 + n2;

	n1 = n2;
	n2 = temp;

	return n1;
}


// Imprime un entier � l'�cran
void imprimer(int a) // Fonction unaire, 1 param�tre
{
	cout << a << ", ";
}



int main()
{
	//Soit les deux vecteurs suivantes:
	vector <int> test1(20);
	vector <int> test2;


	// Un foncteur STL (objet fonction) est une classe, donc on peut cr�er 
	// des objets de ce type.
	greater<int> foncteurPlusGrandQue;
	cout << "4 > 5 : " << foncteurPlusGrandQue(4,5) << endl << endl;


	//Utilisation de fonction de <algorithm>
	cout << "Fibonacci : " << endl;
	generate( test1.begin(), test1.end(), fibonacci );  // Fonction g�n�ratrice.
	for_each( test1.begin(), test1.end(), imprimer );	// Ne modifie pas le vecteur
	cout << endl;


	// On peut modifier l'ordre du tri avec un foncteur binaire (qui prend 2 param�tres)
	sort( test1.begin(), test1.end(), greater<int>() );


	// On peut enlever des �l�ments selon un crit�re avec un foncteur unaire.
	// les foncteurs STL comme greater sont binaires. bind2nd les rend unaire!
	cout << endl << "Apres sort et remove_if :" << endl;

	vector <int>::iterator newEnd = remove_if( test1.begin(), test1.end(), bind2nd(greater<int>(), 200) );

	test1.erase( newEnd,test1.end() ); // On doit ensuite nettoyer la fin du vecteur.
	for_each( test1.begin(), test1.end(), imprimer ); // Ne modifie pas le vecteur.

	transform( test1.begin(), test1.end(), back_inserter(test2), bind2nd(plus<int>(),10) );
	cout << endl << "Apres transform :" << endl;
	for_each( test2.begin(), test2.end(), imprimer );

	cout << endl  << "Apres bind2nd : " << endl;
	for_each( test1.begin(), test1.end(), bind2nd(plus<int>(),10) ); // Ne modifie pas.
	for_each( test1.begin(), test1.end(), imprimer ); // Ne modifie pas le vecteur.
	cout << endl;

	return 0;
}

