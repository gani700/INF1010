/****************************************************************************
 * Fichier: Main.cpp
 * Auteur: Inconnu
 * Date: Inconnu
 * Mise a jour : 13 mai 2011
 * Description: Utilisation de foncteur et fonctions generiques +
				manipulation d'algorithmes de la STL
 ****************************************************************************/

#include "PageWeb.h"

#include <algorithm>
#include <iterator>
using namespace std;



template <typename T1, typename T2>
void afficherSecond(const pair<T1, T2>& paire)
{
  cout << paire.second << endl;
}


template <typename T1, typename T2, typename Compar>
vector<T2> valeurs(const map<T1,T2, Compar>& mappe)
{
  typename map<T1,T2,Compar>::const_iterator iter = mappe.begin();
  typename map<T1,T2,Compar>::const_iterator fin = mappe.end();
 

  vector<T2> v;
  v.reserve(mappe.size());

  for (; iter != fin; ++iter)
    v.push_back(iter->second);

  return v;
}


bool comparerParUrl(const PageWeb& p1, const PageWeb& p2)
{
  return (p1.obtenirUrl() < p2.obtenirUrl());
}



int main()
{
  TablePagesWeb pages;

  pages.insert(make_pair("http://www.exemple.com",
			 PageWeb("http://www.exemple.com","Page 1")));

  pages.insert(make_pair("http://www.polymtl.com",
			 PageWeb("http://www.polymtl.com","Page 2")));

  pages.insert(make_pair("http://www.coucou.com",
			 PageWeb("http://www.coucou.com","Page 3")));

  pages.insert(make_pair("http://www.mysite.com",
			 PageWeb("http://www.mysite.com","Page 4")));


  // Affiche les pages selon leur ordre dans la map
  cout << "Les pages une fois entrees (plus grand url en premier) :" << endl;
  for_each(pages.begin(),pages.end(), afficherSecond<string,PageWeb>);
  cout << endl;


  // Reaorganise les pages web dans un vecteur selon leur url
  vector<PageWeb> vectPages  = valeurs(pages);
  sort(vectPages.begin(),vectPages.end(),comparerParUrl);


  // Affiche la structure du vecteur organise
  cout << "Les pages une fois reorganisees (plus petit url en premier) :" << endl;
  copy(vectPages.begin(),vectPages.end(), ostream_iterator<PageWeb>(cout,"\n"));
  cout << endl;


  return 0;
}