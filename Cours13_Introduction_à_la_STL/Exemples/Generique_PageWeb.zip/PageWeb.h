/****************************************************************************
 * Fichier: PageWeb.cpp
 * Auteur: William Bussiere
 * Date: 13 mai 2011
 * Mise a jour : 13 mai 2011
 * Description: Definition de la classe PageWeb
 ****************************************************************************/


#include <iostream>
#include <string>
#include <map>
#include <vector>
using namespace std;


class PageWeb;

// Les typedefs pour plus de clarte
typedef string Url; 
typedef map<Url, PageWeb, greater<Url> > TablePagesWeb;


class PageWeb
{
	public:
	  PageWeb(Url url, const string& contenu); 

	  void   ajouterHyperlien(Url url, string texte);
	  string obtenirUrl() const;
	  string obtenirContenu() const;

	  bool   operator<(const PageWeb& autre) const;

	private:
		Url url_;
		string contenu_;
		map<string, Url> hyperliens_;
};

// Surchage de l'operateur << pour l'utilistion d'algorithme
ostream& operator<< ( ostream& out, const  PageWeb& page );