/****************************************************************************
 * Fichier: PageWeb.cpp
 * Auteur: William Bussiere
 * Date: 13 mai 2011
 * Mise a jour : 13 mai 2011
 * Description: Implementation de la classe PageWeb
 ****************************************************************************/


#include "PageWeb.h"

PageWeb::PageWeb(Url url, const string& contenu) 
	: url_(url), contenu_(contenu) 
{ 
}


void PageWeb::ajouterHyperlien(Url url, string texte)
{
	hyperliens_.insert( make_pair< Url, string > (url, texte) );
}


string PageWeb::obtenirUrl() const 
{ 
	return url_; 
}


string PageWeb::obtenirContenu() const 
{ 
	return contenu_; 
}


bool PageWeb::operator<(const PageWeb& autre) const 
{ 
	return contenu_ < autre.contenu_; 
}


ostream& operator<<( ostream& out, const  PageWeb& page )
{
  out << page.obtenirContenu();

  return out;
}