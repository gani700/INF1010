/****************************************************************************
 * Fichier: Main.cpp
 * Auteur: William Bussiere
 * Date: 27 mai 2011
 * Description: Manipulations de conteneurs associatifs de la STL
 ****************************************************************************/

#include <iostream>
#include <string>

#include <set>
#include <map>
using namespace std;

// Devrait normalement �tre dans des fichiers s�par�s 
class Marathonien
{
public :
	Marathonien(string nom, double temps) 
		: nom_(nom), temps_(temps) {}
	bool operator< (Marathonien marathonien) const 
		{ return temps_ < marathonien.temps_; }
	void afficher() const
		{ cout << nom_ << " : 40km fait en " << temps_ << endl; }
private :
	string nom_;
	double temps_;
};


int main( void )
{
	/* Les ensembles */
	cout << " // LES SETS // " << endl;

	// Inserer des elements dans un set trie automatiquement les elements
	set<int> perfectionniste;

	// On met quelques nombres dans le set
	perfectionniste.insert( -9 );
	perfectionniste.insert( 128 );
	perfectionniste.insert( 512 );
	perfectionniste.insert( -17 );
	perfectionniste.insert( -1025 );
	perfectionniste.insert( 4096 );
	perfectionniste.insert( 2048 );

	// On peut maintenant afficher le contenu du set
	// Ici, nous somme oublige de passer par les iterateurs
	set<int>::iterator itSet = perfectionniste.begin();
	cout << "Quel plaisir de trier des nombres"<< endl;
	for(itSet; itSet != perfectionniste.end(); ++itSet)
		cout << *itSet << ", ";
	cout << endl << endl;


	// On a decider de retirer quelques nombre au set
	perfectionniste.erase( -17 );
	if( perfectionniste.erase( 512 ) )
		cout << "512 a bien ete retire" << endl;
	else
		cout << "512 ne se trouvait pas dans le set" << endl;

	// et on ajoute quelques elements au set
	// Noubliez pas que insert retourne une pair<iterator, bool>
	if( perfectionniste.insert( -33 ).second )
		cout << "-33 a bien ete ajoute, donc il ne s'y trouvait pas deja" << endl;
	else
		cout << "-33 se trouvait deja dans le set" << endl;
	cout << endl;

	// On reaffiche le contenu du set
	cout << "Contenu modifie du set"<< endl;
	for(itSet = perfectionniste.begin(); itSet != perfectionniste.end(); ++itSet)
		cout << *itSet << ", ";
	cout << endl << endl;


	// On peut aussi stocker des Marathonien dans un set puisque l'operateur<
	// y est surcharge
	set<Marathonien> wmm;

	wmm.insert( Marathonien("Paula Radcliffe", 2.1525) );
	wmm.insert( Marathonien("Yoko Shibui", 2.1941) );
	wmm.insert( Marathonien("Paul Tergat", 2.0455) );
	wmm.insert( Marathonien("Duncan Kibet", 2.0427) );
	wmm.insert( Marathonien("Abel Kirui",  2.0504) );

	// On affiche le set de marathoniens
	set<Marathonien>::iterator itMarathon;
	for(itMarathon = wmm.begin(); itMarathon != wmm.end(); ++itMarathon)
		itMarathon->afficher();
	cout << endl << endl;
	
	/* Les maps */
	cout << " // LES MAPS // " << endl;

	// Manipulations de map avec acces direct au element
	map<string, double> constantes;

	constantes["E"] = 2.71828183;	// Par conventation on va mettre
	constantes["PI"] = 3.14159265;	// la clef en majuscule
	constantes["OR"] = 1.61803398;

	cout << "Les constantes stockees sont (acces directs) : " << endl;
	cout << " e : " << constantes["E"] << endl;
	cout << " pi : " << constantes["PI"] << endl;
	cout << " nombre d'or : " << constantes["OR"] << endl;
	cout << endl;


	// Mais on peut aussi parcourir le map avec des iterateurs
	cout << "Les constantes stockees sont (acces par iterateurs) : " << endl;
	map<string, double>::const_iterator itConst;
	for(itConst = constantes.begin(); itConst != constantes.end(); ++itConst)
		cout << itConst->first << " : " << itConst->second << endl;
	cout << endl;


	// Admettons que l'on voulait acceder la clef 'E' mais que l'on accede
	// a 'e' a la place. Qu'est ce qui arrivera?
	cout << "e : " << constantes["e"] << endl;
	cout << endl;

	cout << "Voici le contenu du vecteur apres cet acces : " << endl;
	for(itConst = constantes.begin(); itConst != constantes.end(); ++itConst)
		cout << itConst->first << " : " << itConst->second << endl;
	cout << endl;

	// Un acces a une clef non presente dans la map cree automatiquement 
	// la clef et construit par defaut l'objet associe.

	return 0;
}