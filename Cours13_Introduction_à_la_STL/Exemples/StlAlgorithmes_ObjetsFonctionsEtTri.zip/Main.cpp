/****************************************************************************
 * Fichier: Main.cpp
 * Auteur: William Bussiere
 * Date: 31 mai 2011
 * Mise a jour : 31 mai 2011
 * Description: Manipulations d'algorithmes de la STL avec foncteurs
 ****************************************************************************/


#include <string>
#include <iostream>
#include <cstdlib>
#include <ctime>

#include <algorithm>
#include <iterator>
#include <set>
#include <vector>
#include <functional>
using namespace std;


/****************************************************************************
 * Classe:		Aleatoire<T>
 * Description: Foncteur generateur d'entiers aleatoires compris entre 
 *				[0 , max_[
 ****************************************************************************/
template<typename T>
class Aleatoire
{
public :
	Aleatoire(const T& max) : max_(max) {}

	T operator() ()
	{
		return rand()%max_;
	}

private :
	T max_;
};


/****************************************************************************
 * Fonction:	afficherSet
 * Description: Affiche l'entierete d'un set en separant les elements par
 *				un espace.
 * Param�tres:	- (set<T,S>) leSet : celui a afficher
 * Retour:		aucun
 ****************************************************************************/
template<typename T, typename S>
void afficherSet(set<T,S> leSet)
{
	set<T,S>::iterator it = leSet.begin();
	
	for(it; it != leSet.end(); it++)
		cout << *it << ' ';
	cout << endl << endl;
}


/****************************************************************************
 * Classe:		Centre<T>
 * Description: Foncteur qui trie des elements selon leur distance
 *				a un centre donne
 ****************************************************************************/
template<typename T>
class Centre
{
public :
	Centre(const T &centre=50) : centre_(centre) {}

	bool operator() (const T& elem1, const T& elem2) const
	{
		T dist1 = centre_ - elem1;
		if( dist1 < 0 )
			dist1 *= -1;

		T dist2 = centre_ - elem2;
		if( dist2 < 0 )
			dist2 *= -1;

		if( dist1 < dist2 )
			return true;

		return false;
	}
private :
	T centre_;
};


int main(void)
{
	srand( (unsigned int) time(NULL) );

	// Quelque entiers less<>
	set<int> quelquesEntiers;

	// Utilisation d'un adaptateur d'iterateur pour un conteneur associatif (inserter)
	generate_n(inserter(quelquesEntiers, quelquesEntiers.begin()), 10, Aleatoire<int>(100) );

	// Affichage 
	cout << "Quelques entiers < : " << endl;
	afficherSet(quelquesEntiers);


	// Quelques entiers re-tries avec greater<>
	set<int, greater<int>> quelquesEntiersRetriesGreater(quelquesEntiers.begin(), quelquesEntiers.end());

	cout << "Quelques entiers retries > : " << endl;
	afficherSet(quelquesEntiersRetriesGreater);
	
	// Quelques entiers retries Centre<>(50)
	set<int, Centre<int> > quelquesEntiersRetriesCentres(quelquesEntiers.begin(), quelquesEntiers.end());

	cout << "Quelques entiers retries centres a 50 : " << endl;
	afficherSet(quelquesEntiersRetriesCentres);

	// On ne peut pas tranformer un set, car on ne peut modifier 
	// la valeur d'un item d'un set directement.
	vector<int> vectQuelquesEntiersRetriesCentres(quelquesEntiersRetriesCentres.begin(), quelquesEntiersRetriesCentres.end());

	transform( vectQuelquesEntiersRetriesCentres.begin(), vectQuelquesEntiersRetriesCentres.end(),
			   vectQuelquesEntiersRetriesCentres.begin(), negate<int>());


	// On affiche le set inverse et retrier
	set<int, Centre<int> > quelquesEntiersRetriesCentresNegate
		(vectQuelquesEntiersRetriesCentres.begin(), vectQuelquesEntiersRetriesCentres.end());

	cout << "Quelques entiers retries, inverses et centres a 50 : " << endl;
	afficherSet(quelquesEntiersRetriesCentresNegate);

	return 0;
}