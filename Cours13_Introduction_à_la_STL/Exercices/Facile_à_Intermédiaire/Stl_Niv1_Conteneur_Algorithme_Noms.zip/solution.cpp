// A) Quel est le meilleur conteneur pour ajouter des noms au
// debut et a la fin du conteneur? Justifier.

//Deque : Permet l'ajout aux deux extremites et plus rapide a parcourir qu'une liste.


// B) Completez le code suivant avec le conteneur selectionne en
// A)

#include <deque>  //Inscrivez le conteneur
#include <algorithm>
#include <iostream>
#include <string>


using namespace std;

// Pour inserer une fonction supplementaire si requise


void afficher( string nom )
{

	cout << nom << endl;

}


int main()
{
	//Creez un instance du conteneur pour des string
	deque < string > noms;

	//Ajoutez "Jacques" et "Robert" a la fin du conteneur
	noms.push_back( "Jacques" );
	noms.push_back( "Robert" );

	//Affichez le contenu du conteneur avec un iterateur et
	//une structure de repetition for

	deque <string>::iterator iter;

	for(iter = noms.begin(); iter != noms.end(); ++iter)
		cout << *iter << endl;


	//Ajoutez "Yves" et "Paul" a la fin du conteneur
	noms.push_back( "Yves" );
	noms.push_back( "Paul" );
	

	//Affichez le contenu du conteneur avec for_each
	// for_each(debut, fin, operateur)
	// ou
	//template <class InputIterator, class UnaryFunction>
	//UnaryFunction for_each(InputIterator first, InputIterator last, UnaryFunction f);

	for_each( noms.begin(), noms.end(), afficher);
	
}