
// A) Quel est le meilleur conteneur pour ajouter des noms seulement en d�but et � la 
// fin du conteneur? Justifier.



// B) Compl�tez le code suivant avec le conteneur s�lectionn� en A)

#include < > //Inscrivez le conteneur
#include <algorithm>
#include <iostream>
#include <string>
using namespace std;

// Pour ins�rer une fonction suppl�mentaire si requise



int main()
{
	//Cr�ez un instance du conteneur pour des string

	//Ajoutez "Jacques" et "Robert" � la fin du conteneur

	//Affichez le contenu du conteneur avec un iterateur et une structure de 
	//r�p�tition for

	//Ajoutez "Yves" et "Paul" � la fin du conteneur

	// Affichez le contenu du conteneur avec for_each

	// for_each(d�but, fin, op�rateur) : d�but et fin sont des it�rateurs, op�rateur 
	// est une fonction unaire.

	return 0;
}