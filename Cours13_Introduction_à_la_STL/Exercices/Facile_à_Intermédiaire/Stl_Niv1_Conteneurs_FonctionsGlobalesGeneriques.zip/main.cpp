/****************************************************************************
 * Fichier: main.cpp
 * Auteur: William Bussiere
 * Date: 9 juin 2011
 * Description: Exercice sur les fonctions globales generiques
 ****************************************************************************/

#include <vector>
#include <list>
#include <set>
#include <iostream>
#include <string>
using namespace std;


class Personne
{
public :
	Personne(string nom, int age) : nom_(nom), age_(age) {}
	string getNom() const { return nom_;}	
	int    getAge() const { return age_;}	

private :
	string nom_;
	int age_;
};

ostream& operator<<(ostream& out,const Personne &personne)
{
	out << personne.getNom() << " a " << personne.getAge() << " ans";
}

/****************************************************************************
 * Fonction:	afficherVecteur
 * Description: Affiche les donnees d'un vecteur sur la meme ligne et separees
 *				par des virgule : ", ".
 * Param�tres:	- (// a specifier //) vecteur : vecteur a afficher (IN)
 * Retour:		aucun
 ****************************************************************************/



/****************************************************************************
 * Fonction:	afficherConteneur
 * Description: Affiche les donnees d'un conteneur sur la meme ligne et 
 *				separees par des virgule : ", ".
 * Param�tres:	- (// a specifier //) conteneur : conteneur a afficher (IN)
 *				- (// a specifier //) iterateur : parcourera le conteneur jusqu'a la fin (IN)
 * Retour:		aucun
 ****************************************************************************/



int main(void)
{
	// Declaration de plusieur vecteur de types differents
	vector<int> mesInts;

	mesInts.push_back(3);
	mesInts.push_back(2);
	mesInts.push_back(4);
	mesInts.push_back(9);


	vector<double> mesDoubles;

	mesDoubles.push_back(9.0);
	mesDoubles.push_back(3.8);
	mesDoubles.push_back(5.1);
	mesDoubles.push_back(3.4);


	vector<string> mesStrings;

	mesStrings.push_back("Vous etes curieux");
	mesStrings.push_back("De regarder mes strings");
	mesStrings.push_back("Qui defilent sous vos yeux");
	mesStrings.push_back("Trop vite pour en voir le deroulement.");

	// Vous devez appelez la fonction afficherVecteur() avec chacun de mesVecteurs



	// Declaration de deux autres conteneurs
	cout << endl;
	list<Personne> mesPersonnes;

	mesPersonnes.push_back( Personne("Guildenstern", 32) );
	mesPersonnes.push_back( Personne("Rosencrantz", 38) );
	mesPersonnes.push_back( Personne("Ophelia", 29) );

	set<int> mesNumeros;

	mesNumeros.insert( 80 );
	mesNumeros.insert( 25 );
	mesNumeros.insert( 33 );


	// Vous devez appeler la fonction afficherConteneur() avec le vecteur
	// meDoubles et la list et le set dernierement crees


	cout << endl;
	return 0;
}