/****************************************************************************
 * Fichier: Main.cpp
 * Auteur: William Bussiere
 * Date: 12 mai 2011
 * Description: Exemples d'une classe et d'une fonction generiques
 ****************************************************************************/

#include "Pair.h"

#include <iostream>
#include <string>
using namespace std;


template < typename T >
void printTable(T tab[], int nb)
{
	cout << "[";

	for (int i = 0; i < nb; ++i) 
	{
		if (i > 0) 
			cout << ",";

		cout << tab[i];
	}

	cout << "]" << endl;
}

int main()
{
	int tabInt[] = { 5, 3, 6, 1, 7 };
	char tabChar[] = { 'A', 'c', 'T', 'Y', 'z' };
	double tabDouble[] = { 5.0, 3.5, 6.1, 1.5, 7.2 };
	string tabString[] = { "ABCD", "DFV", "REX", "QGDSH", "DSFGD" };

// Premi�re partie

	cout << "Les tables : " << endl;
	printTable(tabInt, 5);
	printTable(tabChar, 5);
	printTable(tabDouble, 5);
	printTable(tabString, 5);
	cout << endl;


// Deuxi�me partie

	Pair<int, double> paire1(5, 10.0);
	Pair<string, char> paire2("ABCDE", 'c');
	Pair<int, int> paire3(5, 8);

	cout << "Les paires :" << endl;
	cout << paire1.getFirst() << "  |  " << paire1.getSecond() << endl;
	cout << paire2.getFirst() << "  |  " << paire2.getSecond() << endl;
	cout << paire3.getFirst() << "  |  " << paire3.getSecond() << endl;


	return 0;
}
