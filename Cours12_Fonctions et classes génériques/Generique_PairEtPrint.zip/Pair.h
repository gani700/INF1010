#ifndef _PAIR_H_
#define _PAIR_H_

template< typename F, typename S >
class Pair
{
	public:
		Pair(const F& a, const S& b);
		F getFirst() const;
		S getSecond() const;
	private:
		F first_;
		S second_;
};

template< typename F, typename S >
Pair<F,S>::Pair(const F& a, const S& b)
	: first_(a), second_(b)
{
}

template< typename F, typename S >
F Pair<F,S>::getFirst() const
{
	return first_;
}

template< typename F, typename S >
S Pair<F,S>::getSecond() const
{
	return second_;
}

#endif // _PAIR_H_
